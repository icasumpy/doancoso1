# QuanLyKhachSan Java
QuanLyKhachSan-SQL Server 2008 R2 - JDBC - Netbean
